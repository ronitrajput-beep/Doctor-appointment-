from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
import pytest
from fastapi.testclient import TestClient
from app import database as db, appointments as ap, security as auth
from app.main import app

PASS='TestingPass123!'
def submit(c,email='patient@example.com',password=PASS):
    return c.post('/api/auth/login',json={'email':email,'password':password})
def slots(c):return c.get('/api/doctors/doctor-1/availability').json()
def book(c,sid,payment='success'):return c.post('/api/appointments',json={'slot_id':sid,'payment_result':payment})
def snapshot():
    return {t:db.rows(f'SELECT * FROM {t} ORDER BY rowid') for t in ['appointments','payments','availability','notifications']}

@pytest.mark.parametrize('case',['LG-01','LG-02','LG-03','LG-04','LG-05','LG-06','LG-07','LG-08'])
def test_login(env,case):
    c,login=env
    if case=='LG-01':
        r=submit(c);assert r.status_code==200;assert r.json()['role']=='patient';assert c.get('/api/auth/me').status_code==200;assert 'httponly' in r.headers['set-cookie'].lower()
    elif case=='LG-02':assert submit(c,password='WrongPass123!').status_code==401
    elif case=='LG-03':assert submit(c,email='unknown@example.com').status_code==401
    elif case=='LG-04':assert submit(c,email='',password='').status_code==422
    elif case=='LG-05':assert submit(c,email='aarav.test@').status_code==422
    elif case=='LG-06':
        with db.transaction() as conn:conn.execute("UPDATE users SET active=0 WHERE user_id='user-patient'")
        assert submit(c).status_code==401
    elif case=='LG-07':
        for role in ['patient','doctor','admin']:
            user=login(role);assert user.get('/api/auth/me').json()['role']==role
        assert login().get('/api/admin/users').status_code==403
        for i in range(1,7):
            doctor=TestClient(app)
            email='doctor@example.com' if i==1 else f'doctor{i}@example.com'
            assert submit(doctor,email=email).status_code==200
            assert doctor.get('/api/doctor/profile').json()['doctor_id']==f'doctor-{i}'
            assert book(doctor,'any-slot').status_code==403
            assert doctor.get('/api/admin/excel/export').status_code==403

    elif case=='LG-08':
        user=login();token=user.cookies.get(auth.COOKIE);assert user.post('/api/auth/logout').status_code==200
        user.cookies.set(auth.COOKIE,token);assert user.get('/api/auth/me').status_code==401

@pytest.mark.parametrize('case',['BK-01','BK-02','BK-03','BK-04','BK-05','BK-06','BK-07','BK-08'])
def test_booking(env,case):
    c,login=env;p=login();sid=slots(p)[0]['slot_id']
    if case=='BK-01':
        before=db.one('SELECT count(*) n FROM appointments')['n'];r=book(p,sid);assert r.status_code==201
        a=r.json();assert a['booking_status']=='confirmed';assert a['payment_status']=='simulated_paid';assert a['amount']==1200
        assert db.one('SELECT count(*) n FROM appointments')['n']==before+1
        assert db.one('SELECT status FROM availability WHERE slot_id=?',(sid,))['status']=='booked'
    elif case=='BK-02':
        before=snapshot();assert book(c,sid).status_code==401;assert snapshot()==before
    elif case=='BK-03':
        assert book(p,sid).status_code==201;before=snapshot();assert book(login('patient2'),sid).status_code==409;assert snapshot()==before
    elif case=='BK-04':
        with db.transaction() as conn:conn.execute("UPDATE availability SET appointment_date='2000-01-01' WHERE slot_id=?",(sid,))
        before=snapshot();assert book(p,sid).status_code==422;assert snapshot()==before
    elif case=='BK-05':
        before=snapshot();assert book(p,sid,'failure').status_code==402;assert snapshot()==before
    elif case=='BK-06':
        before=db.one('SELECT count(*) n FROM appointments')['n'];assert book(p,sid,'failure').status_code==402;assert book(p,sid).status_code==201
        assert db.one('SELECT count(*) n FROM appointments')['n']==before+1
    elif case=='BK-07':
        cookies=dict(p.cookies)
        def attempt(_):
            with TestClient(app) as other:
                other.cookies.update(cookies);return book(other,sid).status_code
        with ThreadPoolExecutor(max_workers=8) as pool:codes=list(pool.map(attempt,range(8)))
        assert sorted(codes)==[201]+[409]*7
        assert db.one("SELECT count(*) n FROM appointments WHERE slot_id=? AND booking_status='confirmed'",(sid,))['n']==1
    elif case=='BK-08':
        r=book(p,sid);assert r.status_code==201;a=r.json();assert p.post('/api/auth/logout').status_code==200
        db.initialize();other=login();actual=other.get('/api/appointments/'+a['appointment_id']);assert actual.status_code==200;assert actual.json()==a

@pytest.mark.parametrize('offset,expected',[(-1,422),(0,422),(1,201)],ids=['before','exact','after'])
def test_time_boundary(env,monkeypatch,offset,expected):
    _,login=env;p=login();sid=slots(p)[0]['slot_id'];fixed=datetime(2030,1,15,10,0,tzinfo=db.TZ);when=fixed+timedelta(minutes=offset)
    with db.transaction() as conn:conn.execute('UPDATE availability SET appointment_date=?,start_time=?,end_time=? WHERE slot_id=?',(when.date().isoformat(),when.strftime('%H:%M'),(when+timedelta(minutes=30)).strftime('%H:%M'),sid))
    monkeypatch.setattr(db,'now',lambda:fixed)
    assert book(p,sid).status_code==expected

def test_missing_slot_and_nonpatient_role(env):
    _,login=env;p=login();assert book(p,'missing').status_code==404
    assert book(login('doctor'),slots(p)[0]['slot_id']).status_code==403

def test_inactive_doctor_slot(env):
    _,login=env;p=login();sid=slots(p)[0]['slot_id']
    with db.transaction() as c:c.execute("UPDATE users SET active=0 WHERE user_id='user-doctor-1'")
    assert book(p,sid).status_code==404

def test_rollback_after_database_writes(env,monkeypatch):
    _,login=env;p=login();sid=slots(p)[0]['slot_id'];before=snapshot()
    def fail(*args):raise RuntimeError('Deliberate lab fault after appointment and payment writes')
    monkeypatch.setattr(db,'notify',fail)
    with TestClient(app,raise_server_exceptions=False) as c:
        c.cookies.update(dict(p.cookies));assert book(c,sid).status_code==500
    assert snapshot()==before

def test_password_verification_unit():
    encoded=auth.hash_password(PASS)
    assert auth.verify(PASS,encoded) is True
    assert auth.verify('WrongPass123!',encoded) is False
    assert auth.verify(PASS,'malformed') is False
