Updated Experiment 9 — 26 October 2026
Source baseline: cb1f2e03473ce691f4e1b8cdbf61c13f3d8e1aaf (doctor workspace).

The original report format is preserved: Word styles, section settings, headings, table row/column counts and image-frame dimensions match. PDF remains 10 pages.

New focused run: 38 passed in 43.21 seconds (23 main/supporting cases + 15 clinical extension tests).
Latest recorded full regression: 41 passed in 38.56 seconds.
Latest recorded browser run: 9 passed in 28.6 seconds.
These suites overlap and must not be added as unique tests.

Screenshots are from the latest verified browser run and fitted to the original report frames; raw originals are included. All histories shown are fictional. Installation credentials and private databases are excluded.

To rerun the focused suite, use the source baseline above, copy test_experiment9.py into its tests directory, then run .venv/bin/python -m pytest tests/test_experiment9.py tests/test_clinical_workspace.py -v from the project root. Existing tests/conftest.py supplies isolated fixtures.
